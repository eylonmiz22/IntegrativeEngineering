enum UserRole { ADMIN, MANAGER, PLAYER }
