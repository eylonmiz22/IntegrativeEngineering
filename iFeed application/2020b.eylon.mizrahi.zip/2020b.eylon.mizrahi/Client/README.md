# i_feed

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.dev/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.dev/docs/cookbook)

For help getting started with Flutter, view our
[online documentation](https://flutter.dev/docs), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

## Google Maps

To init your google maps go to:
android>app>src>main>AndroidManifest.xml
and change the "GOOGLE_API_KEY" to your key

## directory include

all the project is in this directory except the build directory

## SQL init

you need to post a manager:

{
"userId": {
"domain": "2020b.eylon.mizrahi",
"email": "manager@manager.com"
},
"role": "MANAGER",
"username": "manager",
"avatar": "manager"
}

and this element(map):

{
"elementId": {
"domain": "2020b.eylon.mizrahi",
"id": "53b6a171-2597-482f-8fc6-2525f755dcd5"
},
"type": "map",
"name": "map",
"active": true,
"createdTimestamp": "2020-06-08T08:26:38.000+0000",
"createdBy": {
"userId": {
"domain": "2020b.eylon.mizrahi",
"email": "manager@manager.com"
}
},
"location": {
"lat": 0.0,
"lng": 0.0
},
"elementAttributes": {}
}
