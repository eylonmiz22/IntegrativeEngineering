package acs.boundaries.details;

public enum UserRole {
	ADMIN, MANAGER, PLAYER
}
