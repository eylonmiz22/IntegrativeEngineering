package acs.data;

public enum UserRole {
	ADMIN, MANAGER, PLAYER
}
