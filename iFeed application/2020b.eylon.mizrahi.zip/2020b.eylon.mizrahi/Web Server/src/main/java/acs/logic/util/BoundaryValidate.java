package acs.logic.util;

public interface BoundaryValidate {
	void searchForNullValues(Object boundary);

}
